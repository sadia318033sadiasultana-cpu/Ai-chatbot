import React from "react";
import { createRoot } from "react-dom/client";
import ChatImagesApp from "./ChatImagesApp.jsx";
import "./styles.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ChatImagesApp />
  </React.StrictMode>,
);
