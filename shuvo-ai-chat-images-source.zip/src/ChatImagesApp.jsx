import { useEffect, useRef, useState } from "react";
import { Streamdown } from "streamdown";
import {
  ArrowDown,
  ArrowUp,
  Bot,
  Check,
  CircleAlert,
  Cpu,
  Image as ImageIcon,
  ImagePlus,
  LoaderCircle,
  MessageCircle,
  Plus,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
} from "lucide-react";

const CHAT_STORAGE_KEY = "shuvo-ai-chat-messages-v1";
const IMAGE_STORAGE_KEY = "shuvo-ai-chat-images-v1";
const MAX_CHAT_MESSAGES = 60;

function readLocalJson(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "null");
    return value ?? fallback;
  } catch {
    return fallback;
  }
}

function loadMessages() {
  const value = readLocalJson(CHAT_STORAGE_KEY, []);
  if (!Array.isArray(value)) return [];
  return value
    .filter(
      (message) =>
        message &&
        ["user", "assistant"].includes(message.role) &&
        typeof message.content === "string",
    )
    .slice(-MAX_CHAT_MESSAGES);
}

function loadImages() {
  const value = readLocalJson(IMAGE_STORAGE_KEY, []);
  if (!Array.isArray(value)) return [];
  return value
    .filter(
      (image) =>
        image &&
        typeof image.url === "string" &&
        image.url.startsWith("data:image/png;base64,") &&
        typeof image.prompt === "string",
    )
    .slice(0, 4);
}

async function readResponse(response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      typeof payload.error === "string"
        ? payload.error
        : `The server returned HTTP ${response.status}.`;
    throw new Error(message);
  }
  return payload;
}

function prettyTime(value) {
  try {
    return new Date(value).toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}

export default function ChatImagesApp() {
  const [activeTab, setActiveTab] = useState("chat");
  const [messages, setMessages] = useState(loadMessages);
  const [draft, setDraft] = useState("");
  const [chatBusy, setChatBusy] = useState(false);
  const [chatError, setChatError] = useState("");
  const [health, setHealth] = useState(null);
  const [chatStorageWarning, setChatStorageWarning] = useState("");
  const [imagePrompt, setImagePrompt] = useState("");
  const [images, setImages] = useState(loadImages);
  const [imageBusy, setImageBusy] = useState(false);
  const [imageStatus, setImageStatus] = useState(null);
  const [imageError, setImageError] = useState("");
  const [imageStorageWarning, setImageStorageWarning] = useState("");
  const transcriptRef = useRef(null);
  const chatInputRef = useRef(null);
  const imageInputRef = useRef(null);

  useEffect(() => {
    let live = true;
    const refreshHealth = async () => {
      try {
        const response = await fetch("/api/health", { cache: "no-store" });
        const value = await response.json();
        if (live) setHealth(response.ok ? value : { chat: false });
      } catch {
        if (live) setHealth({ chat: false, unreachable: true });
      }
    };
    void refreshHealth();
    const timer = window.setInterval(refreshHealth, 30000);
    return () => {
      live = false;
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    try {
      if (messages.length) {
        localStorage.setItem(
          CHAT_STORAGE_KEY,
          JSON.stringify(messages.slice(-MAX_CHAT_MESSAGES)),
        );
      } else {
        localStorage.removeItem(CHAT_STORAGE_KEY);
      }
      setChatStorageWarning("");
    } catch {
      setChatStorageWarning("This chat could not be saved in browser storage.");
    }
  }, [messages]);

  useEffect(() => {
    try {
      localStorage.setItem(IMAGE_STORAGE_KEY, JSON.stringify(images.slice(0, 4)));
      setImageStorageWarning("");
    } catch {
      if (images.length)
        setImageStorageWarning(
          "The image is still visible in this tab, but browser storage is full. Download it before leaving.",
        );
    }
  }, [images]);

  useEffect(() => {
    const element = transcriptRef.current;
    if (element) element.scrollTop = element.scrollHeight;
  }, [messages, chatBusy, chatError]);

  useEffect(() => {
    if (!imageBusy) return undefined;
    let live = true;
    const refresh = async () => {
      try {
        const response = await fetch("/api/images/status", { cache: "no-store" });
        if (!response.ok) return;
        const value = await response.json();
        if (live) setImageStatus(value);
      } catch {
        // The generation response is authoritative if status polling fails.
      }
    };
    void refresh();
    const timer = window.setInterval(refresh, 900);
    return () => {
      live = false;
      window.clearInterval(timer);
    };
  }, [imageBusy]);

  const startFreshChat = () => {
    if (chatBusy) return;
    setMessages([]);
    setDraft("");
    setChatError("");
    setActiveTab("chat");
    window.setTimeout(() => chatInputRef.current?.focus(), 0);
  };

  const sendChat = async (event) => {
    event?.preventDefault();
    const content = draft.trim();
    if (!content || chatBusy || health?.chat === false) return;
    const userMessage = {
      id: `user-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      role: "user",
      content,
      createdAt: Date.now(),
    };
    const requestMessages = [...messages, userMessage]
      .slice(-30)
      .map(({ role, content: messageContent }) => ({
        role,
        content: messageContent,
      }));
    setMessages((current) => [...current, userMessage].slice(-MAX_CHAT_MESSAGES));
    setDraft("");
    setChatError("");
    setChatBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: requestMessages }),
      });
      const result = await readResponse(response);
      if (typeof result.content !== "string" || !result.content.trim())
        throw new Error("The server returned an empty model response. No answer was substituted.");
      setMessages((current) =>
        [...current, {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: result.content,
          createdAt: Date.now(),
        }].slice(-MAX_CHAT_MESSAGES),
      );
    } catch (error) {
      setMessages((current) => current.filter((message) => message.id !== userMessage.id));
      setDraft((current) => current || content);
      setChatError(
        error instanceof Error
          ? error.message
          : "The server-side chat request failed. No response was fabricated.",
      );
    } finally {
      setChatBusy(false);
      window.setTimeout(() => chatInputRef.current?.focus(), 0);
    }
  };

  const handleChatKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void sendChat();
    }
  };

  const validateRenderedPng = (dataUrl) =>
    new Promise((resolve, reject) => {
      const probe = new window.Image();
      probe.onload = () => {
        if (probe.naturalWidth !== 512 || probe.naturalHeight !== 512) {
          reject(new Error("The generated PNG did not have the expected 512×512 dimensions."));
          return;
        }
        resolve();
      };
      probe.onerror = () => reject(new Error("The returned PNG could not be decoded by the browser."));
      probe.src = dataUrl;
    });

  const generateImage = async (event) => {
    event?.preventDefault();
    const prompt = imagePrompt.trim();
    if (!prompt || imageBusy) return;
    setImageError("");
    setImageStorageWarning("");
    setImageStatus({ phase: "checking_runtime", message: "Checking the CPU image runtime…" });
    setImageBusy(true);
    try {
      const response = await fetch("/api/images", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const result = await readResponse(response);
      if (
        typeof result.imageDataUrl !== "string" ||
        !result.imageDataUrl.startsWith("data:image/png;base64,")
      )
        throw new Error("The local worker did not return a PNG image. No placeholder was shown.");
      await validateRenderedPng(result.imageDataUrl);
      setImages((current) =>
        [
          {
            createdAt: Date.now(),
            url: result.imageDataUrl,
            prompt,
            width: result.width,
            height: result.height,
            model: result.model,
            generationSeconds: result.generationSeconds,
          },
          ...current,
        ].slice(0, 4),
      );
      setImageStatus({
        phase: "ready",
        message: "A real 512×512 PNG was generated on the local CPU and decoded successfully.",
        ready: true,
      });
    } catch (error) {
      setImageError(
        error instanceof Error
          ? error.message
          : "Local CPU image generation failed. No substitute image was used.",
      );
    } finally {
      setImageBusy(false);
    }
  };

  const modelLabel =
    typeof health?.chatModel === "string" ? health.chatModel : "pretrained model";

  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="Main navigation">
        <a className="brand" href="#chat" onClick={(event) => { event.preventDefault(); setActiveTab("chat"); }}>
          <span className="brand-mark"><Sparkles size={17} strokeWidth={2.2} /></span>
          <span>SHUVO <span className="brand-light">AI</span></span>
        </a>
        <div className="sidebar-section-label">Your tools</div>
        <nav className="feature-nav">
          <button
            type="button"
            className={activeTab === "chat" ? "nav-item selected" : "nav-item"}
            onClick={() => setActiveTab("chat")}
            aria-current={activeTab === "chat" ? "page" : undefined}
          >
            <MessageCircle size={17} /> <span>Chat</span>
            <span className="nav-dot" aria-hidden="true" />
          </button>
          <button
            type="button"
            className={activeTab === "images" ? "nav-item selected" : "nav-item"}
            onClick={() => setActiveTab("images")}
            aria-current={activeTab === "images" ? "page" : undefined}
          >
            <ImageIcon size={17} /> <span>Images</span>
            {images.length > 0 && <span className="nav-count">{images.length}</span>}
          </button>
        </nav>
        {activeTab === "chat" && (
          <button className="new-chat" type="button" onClick={startFreshChat} disabled={chatBusy}>
            <Plus size={16} /> New chat
          </button>
        )}
        <div className="sidebar-note">
          <div className="note-icon"><ShieldCheck size={16} /></div>
          <strong>Two focused tools</strong>
          <p>Real pretrained-model chat through the server; Tiny-SD image generation on this machine’s CPU.</p>
        </div>
        <div className="sidebar-bottom">
          <span className="local-indicator" />
          <span>Separate Chat + Images app</span>
        </div>
      </aside>

      <main className="main-shell">
        <header className="topbar">
          <div className="topbar-title">
            <span className="eyebrow">SHUVO AI · {activeTab === "chat" ? "CONVERSATION" : "LOCAL GENERATION"}</span>
            <h1>{activeTab === "chat" ? "Chat" : "Images"}</h1>
          </div>
          <div className="topbar-actions">
            {activeTab === "chat" ? (
              <span className={`service-badge ${health?.chat ? "service-ready" : health ? "service-down" : ""}`}>
                <span className="service-dot" />
                {health === null ? "Checking server" : health.chat ? `Pretrained · ${modelLabel}` : "Chat unavailable"}
              </span>
            ) : (
              <span className="service-badge"><Cpu size={14} /> Tiny-SD · CPU only</span>
            )}
            {activeTab === "chat" && (
              <button className="topbar-new" type="button" onClick={startFreshChat} disabled={chatBusy} title="Start a fresh chat">
                <Plus size={15} /><span>New chat</span>
              </button>
            )}
          </div>
        </header>

        {activeTab === "chat" ? (
          <section className="chat-view" aria-label="AI chat">
            <div className="transcript" ref={transcriptRef} aria-live="polite" aria-relevant="additions text">
              {messages.length === 0 ? (
                <div className="chat-empty">
                  <div className="empty-emblem"><Sparkles size={25} /></div>
                  <span className="eyebrow">A fresh conversation</span>
                  <h2>What would you like to talk about?</h2>
                  <p>Ask naturally. Replies come from the configured pretrained chat model—not a fixed demo response.</p>
                  <div className="suggestions" aria-label="Example prompts">
                    <button type="button" onClick={() => setDraft("Explain one interesting fact about the night sky in simple language.")}>Tell me something interesting <ArrowDown size={13} /></button>
                    <button type="button" onClick={() => setDraft("Help me plan a calm, productive morning.")}>Help me think something through <ArrowDown size={13} /></button>
                  </div>
                </div>
              ) : (
                <div className="message-list">
                  {messages.map((message) => (
                    <article className={`message-row ${message.role === "user" ? "from-user" : "from-assistant"}`} key={message.id}>
                      <div className={`message-avatar ${message.role === "assistant" ? "bot-avatar" : "user-avatar"}`}>
                        {message.role === "assistant" ? <Bot size={15} /> : <UserRound size={15} />}
                      </div>
                      <div className="message-main">
                        <div className="message-meta">
                          <strong>{message.role === "assistant" ? "SHUVO AI" : "You"}</strong>
                          {message.role === "assistant" && <span>model response</span>}
                          {message.createdAt && <time>{prettyTime(message.createdAt)}</time>}
                        </div>
                        <div className="message-content">
                          {message.role === "assistant" ? <Streamdown>{message.content}</Streamdown> : <p>{message.content}</p>}
                        </div>
                      </div>
                    </article>
                  ))}
                  {chatBusy && (
                    <div className="thinking-row" role="status"><span className="thinking-mark"><LoaderCircle size={16} className="spin" /></span><span>Waiting for the model’s response…</span></div>
                  )}
                </div>
              )}
            </div>

            <div className="composer-wrap">
              {health?.chat === false && (
                <div className="inline-error config-error" role="alert">
                  <CircleAlert size={16} />
                  <span>{health.unreachable ? "The app server is not responding." : "Server-side Chat is not configured. Set OPENAI_API_BASE and OPENAI_API_KEY in the server environment; no client-side key is used."}</span>
                </div>
              )}
              {chatError && <div className="inline-error" role="alert"><CircleAlert size={16} /><span>{chatError} No canned answer was substituted.</span></div>}
              {chatStorageWarning && <p className="storage-warning" role="status">{chatStorageWarning}</p>}
              <form className="chat-composer" onSubmit={sendChat}>
                <textarea
                  ref={chatInputRef}
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={handleChatKeyDown}
                  placeholder="Message SHUVO AI…"
                  rows={2}
                  maxLength={16000}
                  aria-label="Message SHUVO AI"
                  disabled={chatBusy || health?.chat === false}
                />
                <div className="composer-footer">
                  <span className="composer-caption"><ShieldCheck size={13} /> Server-side model · keys stay private</span>
                  <div className="composer-send-meta">
                    <span>{draft.length ? `${draft.length.toLocaleString()} / 16,000` : "Enter to send · Shift+Enter for a new line"}</span>
                    <button type="submit" className="send-button" disabled={!draft.trim() || chatBusy || health?.chat === false} aria-label="Send message">
                      {chatBusy ? <LoaderCircle size={17} className="spin" /> : <ArrowUp size={18} />}
                    </button>
                  </div>
                </div>
              </form>
              <p className="privacy-caption">Chat history stays in this browser. Submitted messages are sent to the configured server-side model.</p>
            </div>
          </section>
        ) : (
          <ImageStudio
            imagePrompt={imagePrompt}
            setImagePrompt={setImagePrompt}
            images={images}
            setImages={setImages}
            busy={imageBusy}
            status={imageStatus}
            error={imageError}
            storageWarning={imageStorageWarning}
            onGenerate={generateImage}
            inputRef={imageInputRef}
          />
        )}
      </main>
    </div>
  );
}

function ImageStudio({ imagePrompt, setImagePrompt, images, busy, status, error, storageWarning, onGenerate, inputRef }) {
  return (
    <section className="image-view" aria-label="Local CPU image generation">
      <div className="image-intro">
        <div className="image-intro-copy">
          <span className="eyebrow">LOCAL · OPEN-WEIGHT MODEL</span>
          <h2>Turn a description into an image.</h2>
          <p>Segmind Tiny-SD runs locally in a CPU-only Python worker. Image prompts are not sent to a hosted image-generation service.</p>
        </div>
        <div className="image-spec-card">
          <span className="spec-icon"><Cpu size={21} /></span>
          <strong>CPU</strong>
          <small>512 × 512 · 4 steps</small>
        </div>
      </div>

      <form className="image-prompt-card" onSubmit={onGenerate}>
        <label className="image-prompt-label" htmlFor="image-prompt"><ImagePlus size={15} /> Describe the image</label>
        <textarea
          ref={inputRef}
          id="image-prompt"
          value={imagePrompt}
          onChange={(event) => setImagePrompt(event.target.value)}
          placeholder="A quiet mountain lake at dawn, mist over the water, soft film photography…"
          maxLength={800}
          rows={3}
          disabled={busy}
        />
        <div className="prompt-bottom">
          <span>{imagePrompt.length}/800 characters</span>
          <button className="generate-button" type="submit" disabled={!imagePrompt.trim() || busy}>
            {busy ? <><LoaderCircle size={16} className="spin" /> Preparing / generating…</> : <><Sparkles size={16} /> Generate image</>}
          </button>
        </div>
        {busy && (
          <div className="setup-status" role="status" aria-live="polite">
            <LoaderCircle size={15} className="spin" />
            <span>{status?.message || "Preparing the isolated CPU runtime. First use can take several minutes."}</span>
          </div>
        )}
        {error && <div className="inline-error image-error" role="alert"><CircleAlert size={16} /><span>{error}</span></div>}
        {storageWarning && <p className="storage-warning" role="status">{storageWarning}</p>}
        <p className="model-caveat">
          First use auto-installs the pinned CPU packages and downloads about <strong>1.06 GB</strong> of public model weights. Plan for several GB of cache/disk and preferably <strong>8 GB RAM</strong>; the clean-run worker reached <strong>4.13 GiB peak RSS</strong>. Setup and CPU inference can take minutes. The model is lower-fidelity than large GPU systems and includes no safety checker.
        </p>
      </form>

      <div className="gallery-heading">
        <div><span className="eyebrow">THIS BROWSER</span><h3>{images.length ? `${images.length} saved image${images.length === 1 ? "" : "s"}` : "Your image gallery"}</h3></div>
        <span className="gallery-storage"><ShieldCheck size={13} /> Browser storage</span>
      </div>
      {images.length ? (
        <div className="image-gallery">
          {images.map((image, index) => (
            <article className="image-card" key={`${image.createdAt}-${index}`}>
              <a className="image-preview" href={image.url} target="_blank" rel="noreferrer" aria-label="Open generated image">
                <img src={image.url} alt={image.prompt} loading={index > 1 ? "lazy" : "eager"} />
              </a>
              <div className="image-card-info">
                <p>{image.prompt}</p>
                <small>{image.width || 512} × {image.height || 512}{image.generationSeconds ? ` · ${Number(image.generationSeconds).toFixed(1)} s` : ""} · local CPU</small>
                <a className="download-link" href={image.url} download={`shuvo-ai-image-${index + 1}.png`}><ArrowDown size={14} /> Download PNG</a>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="gallery-empty">
          <ImageIcon size={25} />
          <strong>No images yet</strong>
          <span>Your real locally generated PNGs will appear here with a download link.</span>
        </div>
      )}
      <footer className="image-footer"><span><Check size={13} /> Model weights cache locally after their first download.</span><span>Model: <a href="https://huggingface.co/segmind/tiny-sd" target="_blank" rel="noreferrer">Segmind Tiny-SD</a> · CreativeML OpenRAIL-M</span></footer>
    </section>
  );
}
