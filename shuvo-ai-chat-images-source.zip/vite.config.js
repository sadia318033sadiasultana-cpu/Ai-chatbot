import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createLocalImageWorker, LocalImageWorkerError } from "./lib/localImageWorker.js";

const root = path.dirname(fileURLToPath(import.meta.url));
const chatModel = process.env.ORBIT_MODEL || "gpt-5-mini";
const imageWorker = createLocalImageWorker(root);
const chatRequests = new Map();
const imageRequests = new Map();

function sendJson(response, status, payload) {
  response.statusCode = status;
  response.setHeader("Content-Type", "application/json; charset=utf-8");
  response.setHeader("Cache-Control", "no-store");
  response.end(JSON.stringify(payload));
}

function sendError(response, status, code, message, retryable = false) {
  return sendJson(response, status, { error: message, code, retryable });
}

class ApiError extends Error {
  constructor(status, code, message, retryable = false) {
    super(message);
    this.status = status;
    this.code = code;
    this.retryable = retryable;
  }
}

async function readJson(request) {
  let total = 0;
  const chunks = [];
  for await (const chunk of request) {
    total += chunk.length;
    if (total > 700_000)
      throw new ApiError(413, "REQUEST_TOO_LARGE", "Request body exceeds 700 KB.");
    chunks.push(chunk);
  }
  if (!total) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new ApiError(400, "INVALID_JSON", "Request body is not valid JSON.");
  }
}

function allowRequest(map, client, limit, label) {
  const now = Date.now();
  const recent = (map.get(client) || []).filter((timestamp) => now - timestamp < 60_000);
  if (recent.length >= limit)
    throw new ApiError(
      429,
      `${label.toUpperCase()}_RATE_LIMITED`,
      `${label} is limited to ${limit} requests per client per minute. Wait briefly and retry.`,
      true,
    );
  recent.push(now);
  map.set(client, recent);
}

async function callPretrainedChat(messages) {
  const base = process.env.OPENAI_API_BASE?.replace(/\/+$/, "");
  const key = process.env.OPENAI_API_KEY;
  if (!base || !key)
    throw new ApiError(
      503,
      "MODEL_NOT_CONFIGURED",
      "Server-side Chat is not configured. Set OPENAI_API_BASE and OPENAI_API_KEY in the server environment; no client-side key is used.",
    );

  let response;
  try {
    response = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: chatModel,
        messages: [
          {
            role: "system",
            content:
              "You are SHUVO AI, a helpful general-purpose conversational assistant. Respond naturally to the user's intent and in the user's language. Be clear, considerate, and honest about uncertainty. Never claim to be sentient or to have performed actions outside this chat.",
          },
          ...messages,
        ],
        max_completion_tokens: 1400,
        reasoning_effort: "minimal",
      }),
      signal: AbortSignal.timeout(60_000),
    });
  } catch (error) {
    const timedOut = error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError");
    throw new ApiError(
      timedOut ? 504 : 502,
      timedOut ? "MODEL_TIMEOUT" : "MODEL_UNREACHABLE",
      timedOut
        ? "The pretrained chat model timed out. Retry in a moment."
        : "The server could not reach the configured pretrained chat model. Check server logs and retry.",
      true,
    );
  }

  if (!response.ok) {
    const status = response.status;
    console.error(`[Chat API] Upstream returned HTTP ${status}`);
    if (status === 429)
      throw new ApiError(429, "MODEL_RATE_LIMITED", "The model-service rate limit was reached. Wait briefly and retry.", true);
    if (status === 401 || status === 403)
      throw new ApiError(502, "MODEL_AUTH_REJECTED", "The model service rejected its server-side credentials. Check server configuration.");
    throw new ApiError(
      status >= 500 ? 502 : 502,
      status >= 500 ? "MODEL_UPSTREAM_UNAVAILABLE" : "MODEL_UPSTREAM_REJECTED",
      `The model service did not accept the request (upstream HTTP ${status}). Check its configuration and retry.`,
      status >= 500,
    );
  }

  let data;
  try {
    data = await response.json();
  } catch {
    throw new ApiError(502, "MODEL_INVALID_RESPONSE", "The pretrained chat model returned an invalid response.", true);
  }
  const content = data?.choices?.[0]?.message?.content;
  const text = typeof content === "string"
    ? content
    : Array.isArray(content)
      ? content.map((part) => typeof part?.text === "string" ? part.text : "").join("")
      : "";
  if (!text.trim())
    throw new ApiError(502, "MODEL_EMPTY_RESPONSE", "The pretrained chat model returned no text. No canned response was substituted.", true);
  return text.trim();
}

function standaloneApi() {
  const middleware = async (request, response, next) => {
    const pathname = (request.url || "").split("?", 1)[0];
    if (!pathname.startsWith("/api/")) return next();

    if (pathname === "/api/health" && request.method === "GET") {
      return sendJson(response, 200, {
        status: "ok",
        chat: Boolean(process.env.OPENAI_API_BASE && process.env.OPENAI_API_KEY),
        chatModel,
        chatProvider: "server-side OpenAI-compatible pretrained model",
        imageGeneration: true,
        imageGenerationProvider: "local_cpu",
        imageGenerationModel: "segmind/tiny-sd",
        imageSetup: imageWorker.status(),
      });
    }

    if (pathname === "/api/images/status" && request.method === "GET")
      return sendJson(response, 200, imageWorker.status());

    if (pathname !== "/api/chat" && pathname !== "/api/images")
      return sendError(response, 404, "API_ROUTE_NOT_FOUND", "This standalone app exposes only Chat and Images APIs.");

    if (pathname === "/api/chat" && request.method !== "POST")
      return sendError(response, 405, "METHOD_NOT_ALLOWED", "Use POST for Chat.");
    if (pathname === "/api/images" && request.method !== "POST")
      return sendError(response, 405, "METHOD_NOT_ALLOWED", "Use POST for image generation.");

    const client = String(request.socket?.remoteAddress || "unknown");
    try {
      if (pathname === "/api/chat") {
        allowRequest(chatRequests, client, 15, "Chat");
        const body = await readJson(request);
        if (!body || typeof body !== "object" || Array.isArray(body))
          throw new ApiError(400, "INVALID_CHAT_REQUEST", "Send a JSON object containing a messages array.");
        if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 30)
          throw new ApiError(400, "INVALID_CHAT_HISTORY", "Provide between 1 and 30 chat messages.");
        const messages = body.messages.map((message) => {
          if (!message || !["user", "assistant"].includes(message.role) || typeof message.content !== "string" || !message.content.trim() || message.content.length > 16_000)
            throw new ApiError(400, "INVALID_CHAT_MESSAGE", "Each message must have a user/assistant role and non-empty text of at most 16,000 characters.");
          return { role: message.role, content: message.content };
        });
        if (messages.at(-1).role !== "user")
          throw new ApiError(400, "INVALID_CHAT_TURN", "The last message must be the user's current turn.");
        const content = await callPretrainedChat(messages);
        return sendJson(response, 200, { content, model: chatModel, provider: "server-side pretrained model" });
      }

      allowRequest(imageRequests, client, 3, "Image generation");
      const body = await readJson(request);
      if (!body || typeof body !== "object" || Array.isArray(body) || typeof body.prompt !== "string" || !body.prompt.trim() || body.prompt.trim().length > 800)
        throw new ApiError(400, "INVALID_IMAGE_PROMPT", "Provide a non-empty image prompt of at most 800 characters.");
      const result = await imageWorker.generate(body.prompt.trim());
      return sendJson(response, 200, result);
    } catch (error) {
      if (error instanceof ApiError)
        return sendError(response, error.status, error.code, error.message, error.retryable);
      if (error instanceof LocalImageWorkerError)
        return sendError(response, error.status, error.code, error.message, error.status >= 500);
      const code = pathname === "/api/chat" ? "CHAT_FAILED" : "IMAGE_GENERATION_FAILED";
      console.error(`[Local API] ${pathname} failed (${code})`);
      return sendError(response, 500, code, pathname === "/api/chat"
        ? "The server-side chat request failed unexpectedly. No canned answer was returned."
        : "Local CPU image generation failed unexpectedly. Check the server log and retry.", true);
    }
  };

  return {
    name: "shuvo-ai-chat-images-api",
    configureServer(server) { server.middlewares.use(middleware); },
    configurePreviewServer(server) { server.middlewares.use(middleware); },
  };
}

export default defineConfig({
  plugins: [react(), standaloneApi()],
  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    allowedHosts: [".us1.manus.computer", ".us3.manus.computer", ".us4.manus.computer"],
  },
  preview: {
    host: "0.0.0.0",
    port: 4173,
    strictPort: true,
    allowedHosts: [".us1.manus.computer", ".us3.manus.computer", ".us4.manus.computer"],
  },
});
