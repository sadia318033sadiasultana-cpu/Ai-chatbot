# SHUVO AI — Chat + Images

A separate, standalone source project containing only two user-facing features:

1. **Chat** — natural conversational responses from a configured, pretrained model through a server-only OpenAI-compatible API adapter.
2. **Images** — actual 512×512 PNG generation with the pinned Segmind Tiny-SD model, running on CPU in a local Python worker.

The default screen is a fresh Chat. The app changes to Images only when the user selects **Images**. There is no Build/workspace, Search, Review, file creation, upload, or unrelated panel or API route in this source tree.

## Important: pretrained Chat, not custom training

This project calls an already-trained model; it does **not** train or fine-tune a new model. The supplied project contains no training dataset, training pipeline, or training checkpoint, so custom training is not feasible or claimed here. The default server model name is `gpt-5-mini` (configurable with `ORBIT_MODEL`). The precise backend model/version and its availability depend on the OpenAI-compatible service configured by the operator.

Chat credentials are read **only by the server** from `OPENAI_API_BASE` and `OPENAI_API_KEY`. They are never embedded in the browser bundle or returned by `/api/health`. If either setting is absent or the provider fails, Chat reports the actual error; it does not return a demo answer. The test script deliberately uses the live configured endpoint and contains no mock mode.

## Requirements

### Chat and web app

- Node.js 20+ (the supplied sandbox was tested on Node 22)
- pnpm 9+ (or npm, using the same package manifest)
- An available OpenAI-compatible chat-completions endpoint, set as server environment variables:

```bash
export OPENAI_API_BASE="https://your-provider.example/v1"
export OPENAI_API_KEY="your-server-side-key"
# Optional; default: gpt-5-mini
export ORBIT_MODEL="gpt-5-mini"
```

Do not add a real secret to source control, a browser variable, or the client code. The browser talks only to this app's same-origin `/api/chat` endpoint. Chat permits 15 calls per client IP per minute, up to 30 messages per request, with a maximum of 16,000 characters per message.

### Local CPU image generation

The auto-setup path is supported on **Linux x86-64 with Python 3.12**, outbound HTTPS to PyPI, the PyTorch CPU wheel index, and Hugging Face, and writable cache storage. The first image request automatically creates an isolated Python virtual environment outside the source tree, installs the exact versions in `requirements-image-cpu.txt` using CPU-only PyTorch wheels, verifies the package versions and confirms CUDA is unavailable, then downloads the pinned public model weights if they are not cached. No manual dependency-install step is required for first use.

Pinned image stack:

- Python 3.12; Linux x86-64
- `torch==2.14.0+cpu`
- `diffusers==0.40.0`
- `transformers==5.17.0`
- `safetensors==0.8.0`
- `huggingface_hub==1.33.0`
- Model: `segmind/tiny-sd`, revision `cad0bd7495fa6c4bcca01b19a723dc91627fe84f`

The first-use model download is about **1.06 GB**; pinned Python packages add several more GB of network/cache/disk use. Provision **several GB of writable disk** and preferably **8 GB RAM**. In this clean first-use run, package/model setup plus generation took about **80 seconds** and the Python worker reached **4.13 GiB peak RSS (about 4.43 GB decimal)**; the installed environment and model cache occupied **2.2 GiB** afterward. CPU speed, network, and downloads vary, so other hosts may take several minutes. The app reports its current stage and fails honestly if setup, download or inference fails. There is no hosted image-generation fallback.

Generated images are 512×512, four inference steps and CPU-only. Tiny-SD is lower fidelity than large GPU models. This integration does not include a safety checker and is intended for trusted, single-user/private use, not an unauthenticated public image service. Follow the model's [CreativeML OpenRAIL-M model card and license](https://huggingface.co/segmind/tiny-sd). Image generation is limited to three requests per client IP per minute and serialized to one local worker request at a time.

The default environment and model cache live outside the project at `~/.cache/shuvo-ai-chat-images/`. They can be changed with `SHUVO_IMAGE_VENV`, `SHUVO_IMAGE_CACHE`, and `SHUVO_IMAGE_PYTHON`. If that cache is removed on restart, the packages and model must be downloaded again. A static-only host or ephemeral serverless host that cannot run this server-side Python worker is not supported.

## Run

```bash
pnpm install
export OPENAI_API_BASE="https://your-provider.example/v1"
export OPENAI_API_KEY="your-server-side-key"
pnpm dev
```

Open `http://localhost:3000`. The first Chat message is a real server-side model request. Open **Images** and submit a prompt to trigger the one-time CPU environment/model bootstrap and local inference.

Optional explicit dependency setup (auto-setup is otherwise performed on first image generation):

```bash
pnpm setup:image-cpu
```

Production build and app/API preview:

```bash
pnpm build
pnpm preview
```

The preview includes the same Chat, Images, image-status, and health server routes; copying `dist/` to a static-only server is not a complete deployment.

## Verify real Chat

With the app running and its actual provider credentials configured in the server environment:

```bash
pnpm test:live
```

The live smoke test checks the server's configured state, submits two different natural questions, and conducts a two-turn riddle/hint conversation by passing the actual first response into the second request. It prints the live replies and exits on a provider/API failure. It does not use canned fixtures, mock a response, train a model, or test image generation with a substitute image.

## API surface

- `GET /api/health` — server Chat configuration/model label and local image bootstrap state
- `POST /api/chat` — passes validated user/assistant text to the server-side pretrained model
- `GET /api/images/status` — local CPU bootstrap/model status
- `POST /api/images` — starts or reuses CPU setup and returns a generated PNG data URL

Other `/api/*` paths return 404. The model key/base URL are never sent to the browser.
