#!/usr/bin/env python3
"""Local Tiny-SD image worker. Prompts are data only and are never executed."""

from __future__ import annotations

import base64
import io
import json
import os
import sys
import time
import traceback
from collections.abc import Callable

MODEL_ID = "segmind/tiny-sd"
MODEL_REVISION = "cad0bd7495fa6c4bcca01b19a723dc91627fe84f"
MAX_PROMPT_CHARS = 800


def emit(payload: dict[str, object]) -> None:
    sys.stdout.write(json.dumps(payload, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def load_pipeline(report_status: Callable[[str, str], None]):
    # Defense in depth: the parent process also masks CUDA before this worker starts.
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    report_status(
        "loading_model",
        "Loading Tiny-SD on CPU. If its pinned cache is empty, the public model files will download next.",
    )
    import torch
    from diffusers import DPMSolverMultistepScheduler, StableDiffusionPipeline

    if torch.cuda.is_available():
        raise RuntimeError("CUDA is visible; refusing to run the local image worker.")

    cpu_threads = max(1, min(6, os.cpu_count() or 1))
    torch.set_num_threads(cpu_threads)
    torch.set_num_interop_threads(1)

    report_status(
        "downloading_model",
        "Checking the local cache and downloading the pinned public Tiny-SD weights if needed (about 1.06 GB on first use). Download byte progress is not available in this app.",
    )
    pipeline = StableDiffusionPipeline.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
        dtype=torch.float32,
        use_safetensors=False,
        safety_checker=None,
        requires_safety_checker=False,
    )
    pipeline.scheduler = DPMSolverMultistepScheduler.from_config(
        pipeline.scheduler.config
    )
    pipeline.to("cpu")
    report_status("model_ready", "Pinned model weights are cached; preparing CPU inference…")
    return torch, pipeline


def main() -> int:
    torch = None
    pipeline = None

    for line in sys.stdin:
        request_id = None
        try:
            request = json.loads(line)
            request_id = request.get("id")
            prompt = request.get("prompt")
            if not isinstance(prompt, str) or not prompt.strip():
                emit({"id": request_id, "ok": False, "code": "INVALID_PROMPT"})
                continue
            prompt = prompt.strip()
            if len(prompt) > MAX_PROMPT_CHARS:
                emit({"id": request_id, "ok": False, "code": "PROMPT_TOO_LONG"})
                continue

            if pipeline is None:
                torch, pipeline = load_pipeline(
                    lambda phase, message: emit(
                        {
                            "id": request_id,
                            "event": "status",
                            "phase": phase,
                            "message": message,
                        }
                    )
                )

            emit(
                {
                    "id": request_id,
                    "event": "status",
                    "phase": "generating",
                    "message": "Generating a 512×512 image on the CPU using four inference steps…",
                }
            )
            generation_started = time.perf_counter()
            with torch.inference_mode():
                result = pipeline(
                    prompt,
                    height=512,
                    width=512,
                    num_inference_steps=4,
                    guidance_scale=7.5,
                )
            image = result.images[0]
            buffer = io.BytesIO()
            image.save(buffer, format="PNG", optimize=True)
            image_data = base64.b64encode(buffer.getvalue()).decode("ascii")
            emit(
                {
                    "id": request_id,
                    "ok": True,
                    "imageDataUrl": "data:image/png;base64," + image_data,
                    "width": image.width,
                    "height": image.height,
                    "model": MODEL_ID,
                    "revision": MODEL_REVISION,
                    "generationSeconds": round(time.perf_counter() - generation_started, 2),
                }
            )
        except json.JSONDecodeError:
            emit({"id": request_id, "ok": False, "code": "INVALID_WORKER_REQUEST"})
        except Exception as error:  # Return bounded errors; details stay server-side.
            traceback.print_exc(file=sys.stderr)
            code = "LOCAL_IMAGE_MODEL_FAILED"
            if isinstance(error, (ImportError, ModuleNotFoundError)):
                code = "IMAGE_RUNTIME_NOT_INSTALLED"
            emit({"id": request_id, "ok": False, "code": code})

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
