#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
IMAGE_VENV="${SHUVO_IMAGE_VENV:-${XDG_CACHE_HOME:-$HOME/.cache}/shuvo-ai-chat-images/image-venv}"
IMAGE_CACHE="${SHUVO_IMAGE_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/shuvo-ai-chat-images/huggingface}"
PYTHON="${SHUVO_IMAGE_PYTHON:-python3}"
case "$(realpath -m "$IMAGE_VENV")" in
  "$(realpath -m "$PWD")"|"$(realpath -m "$PWD")"/*)
    echo "The image virtual environment must be outside the app source tree." >&2
    exit 2
    ;;
esac
case "$(realpath -m "$IMAGE_CACHE")" in
  "$(realpath -m "$PWD")"|"$(realpath -m "$PWD")"/*)
    echo "The image model cache must be outside the app source tree." >&2
    exit 2
    ;;
esac
"$PYTHON" -c 'import platform, sys; assert platform.system() == "Linux" and platform.machine().lower() in ("x86_64", "amd64") and sys.version_info[:2] == (3, 12), "Requires Linux x86-64 and Python 3.12"'
mkdir -p "$(dirname "$IMAGE_VENV")" "$IMAGE_CACHE"
"$PYTHON" -m venv "$IMAGE_VENV"
HF_HOME="$IMAGE_CACHE" PIP_NO_INPUT=1 "$IMAGE_VENV/bin/python" -m pip install --disable-pip-version-check --no-input -r requirements-image-cpu.txt
printf '\nPinned CPU image dependencies installed outside the source tree. Start the app with: pnpm dev\n'
printf 'The first image request downloads about 1.06 GB of pinned public Tiny-SD weights.\n'
printf 'Custom virtual environment path: %s\nCustom model cache path: %s\n' "$IMAGE_VENV" "$IMAGE_CACHE"
