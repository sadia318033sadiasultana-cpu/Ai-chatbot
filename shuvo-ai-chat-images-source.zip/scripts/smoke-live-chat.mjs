const base = (process.env.CHAT_TEST_BASE_URL || "http://127.0.0.1:3000").replace(/\/$/, "");

async function call(messages) {
  const response = await fetch(`${base}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages }),
    signal: AbortSignal.timeout(90_000),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(`Live Chat failed with HTTP ${response.status}: ${result.error || "no server error text"}`);
  if (typeof result.content !== "string" || !result.content.trim())
    throw new Error("The real chat endpoint returned no text; no fallback/mock is accepted.");
  return { content: result.content.trim(), model: result.model || "unspecified" };
}

async function main() {
  const healthResponse = await fetch(`${base}/api/health`, { cache: "no-store" });
  const health = await healthResponse.json();
  if (!healthResponse.ok || health.chat !== true)
    throw new Error("The server reports that its real server-side pretrained chat model is not configured.");

  const checks = [];
  checks.push({
    label: "Natural question — practical advice",
    messages: [{ role: "user", content: "What is one realistic way to build a small daily reading habit? Please answer conversationally in 2–3 sentences." }],
  });
  checks.push({
    label: "Different natural question — explanation",
    messages: [{ role: "user", content: "Why does a metal spoon feel colder than a wooden spoon in the same room? Explain simply." }],
  });

  for (const check of checks) {
    const result = await call(check.messages);
    console.log(`\nPASS · ${check.label} · model ${result.model}\n${result.content}`);
  }

  const firstUser = "My niece likes astronomy. Ask her a short, friendly riddle about the Moon, but don't reveal the answer.";
  const first = await call([{ role: "user", content: firstUser }]);
  console.log(`\nPASS · Multi-turn exchange, turn 1 · model ${first.model}\n${first.content}`);
  const followup = await call([
    { role: "user", content: firstUser },
    { role: "assistant", content: first.content },
    { role: "user", content: "Give one gentle hint for that same riddle without telling the answer." },
  ]);
  if (followup.content.length < 12)
    throw new Error("The multi-turn follow-up was unexpectedly short.");
  console.log(`\nPASS · Multi-turn exchange, turn 2 (uses the actual first reply as context) · model ${followup.model}\n${followup.content}`);
  console.log("\nAll checks used the live server-side model endpoint. No mock, fixed answer, or hosted image fallback was used.");
}

main().catch((error) => {
  console.error(`FAIL · ${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
